namespace Trackii.Api.Contracts;

public sealed record LoginRequest(string Username, string Password, string DeviceUid);
