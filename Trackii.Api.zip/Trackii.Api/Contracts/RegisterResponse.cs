namespace Trackii.Api.Contracts;

public sealed record RegisterResponse(uint UserId, uint DeviceId);
